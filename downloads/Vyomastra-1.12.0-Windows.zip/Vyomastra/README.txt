Vyomastra 1.12.0 for Windows - a free space shooter by CodingCush
https://games.codingcush.com/vyomastra/

To play: double-click Vyomastra.exe. Nothing to install.

If Windows shows "Windows protected your PC": click "More info", then "Run anyway".
(The game is new and not signed with a paid certificate yet, so Windows does not recognise it.)

Offline: everything works without internet. Your progress is saved on this computer.
Online: sign in with your email (Account in the menu) to keep progress in the cloud
and put your scores on the global leaderboard.

Controls: arrows or WASD to move, Space or J to fire, Esc or P to pause.
A mouse or a gamepad works too. F11 switches full screen.
